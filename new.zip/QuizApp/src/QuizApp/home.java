package QuizApp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class home {
	public static void main(String[]args) {


	
	try {
		Class.forName("com.mysql.jdbc.Driver");  
		Connection con=DriverManager.getConnection(  
		"jdbc:mysql://localhost:3306/quizapp","root","");  
		//here sonoo is database name, root is username and password  
		Statement stmt=con.createStatement();  
	    System.out.println("dbconnected");
		con.close();  
	} catch(Exception e){
		System.out.println("OOPS: Database Not Connected");
       
	} 
 }

}
