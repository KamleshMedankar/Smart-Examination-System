package QuizApp;

import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

import com.mysql.jdbc.JDBC4ResultSet;
import com.mysql.jdbc.PreparedStatement;



import javax.swing.JTextField;
import javax.swing.JTextPane;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;

public class StudData {

	private JFrame frame;
	private JTextField name;
	private JTextField address;
	private JTextField studid;
	private JTextField rollno;
	private JTextField mob;
	private JTextField pass;
	private JComboBox Divi;
	private JComboBox Clas;
    private String Name;
	/**
	 * Launch the application.
	 * @throws ClassNotFoundException 
	 */
	
    
   	void my_db_update (String Name,String Clas,String Address,String Division,String Stuid,String Mob,String Pass) throws ClassNotFoundException 
	{
		 Class.forName("com.mysql.jdbc.Driver");
		 Connection conn = null;
	     Statement stmt = null;
		   try {
			conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/quizapp","root","");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		   
	     try {
			stmt = (Statement) conn.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 String sql = "insert into studinfo"+"(`Name`, `Address`, `Class`, `StudentId`, `Pass`, `Divi`, `MobNo`)"+" values('"+Name+"','"+Address+"','"+Clas+"','"+Stuid+"','"+Pass+"','"+Division+"','"+Mob+"')";
		 
		   
         
		 
		 try {
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		 
		 JOptionPane.showMessageDialog(null,"Data Inserted");
			StudData window = new StudData();
			window.frame.setVisible(true);
	}
	
	public static void main(String[] args) {
		
		
		
	
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudData window = new StudData();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}	
		

	/**
	 * Create the application.
	 */
	public StudData() {
		initialize();
		

	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Add Student Page");
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("O:\\java assignment\\QuizApp\\img\\male-user-add_25347.png"));
		Toolkit kit = Toolkit.getDefaultToolkit();
	    Dimension screenSize=kit.getScreenSize();
		int screenWidth = screenSize.width;
		int screenHeight = screenSize.height;
        frame.setSize(screenWidth,screenHeight);
		
		frame.setLocationRelativeTo(null);
		
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(0, 0, 0));
		panel.setBounds(0, 51, 1350, 678);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Add New Student");
		lblNewLabel.setForeground(SystemColor.textHighlightText);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 35));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(0, 46, 1350, 50);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Name :");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1.setBounds(85, 172, 104, 35);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Address :");
		lblNewLabel_1_1.setForeground(SystemColor.text);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_1.setBounds(85, 272, 104, 35);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Class :");
		lblNewLabel_1_2.setForeground(SystemColor.text);
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_2.setBounds(85, 372, 104, 35);
		panel.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Division :");
		lblNewLabel_1_3.setForeground(SystemColor.text);
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblNewLabel_1_3.setBounds(713, 370, 104, 35);
		panel.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("Student Id :");
		lblNewLabel_1_4.setForeground(SystemColor.text);
		lblNewLabel_1_4.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_4.setBounds(85, 472, 104, 35);
		panel.add(lblNewLabel_1_4);
		
		name = new JTextField();
		name.setFont(new Font("Tahoma", Font.BOLD, 16));
		name.setBackground(SystemColor.control);
		name.setBounds(225, 165, 370, 50);
		panel.add(name);
		name.setColumns(10);
		
		address = new JTextField();
		address.setFont(new Font("Tahoma", Font.BOLD, 16));
		address.setBackground(SystemColor.control);
		address.setColumns(10);
		address.setBounds(225, 265, 370, 50);
		panel.add(address);
		
		studid = new JTextField();
		studid.setFont(new Font("Tahoma", Font.BOLD, 25));
		studid.setBackground(SystemColor.control);
		studid.setColumns(10);
		studid.setBounds(225, 465, 370, 50);
		panel.add(studid);
		
		JLabel lblNewLabel_1_5 = new JLabel("Mobile Number :");
		
		lblNewLabel_1_5.setForeground(SystemColor.text);
		lblNewLabel_1_5.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblNewLabel_1_5.setBounds(713, 170, 167, 35);
		panel.add(lblNewLabel_1_5);
		
		JLabel lblNewLabel_1_6 = new JLabel("Registration Number :");
		lblNewLabel_1_6.setForeground(SystemColor.text);
		lblNewLabel_1_6.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblNewLabel_1_6.setBounds(713, 270, 139, 35);
		panel.add(lblNewLabel_1_6);
		
		rollno = new JTextField();
		rollno.setEditable(false);
		rollno.setForeground(new Color(255, 0, 0));
		rollno.setText("*Registration Number is system generated");
		rollno.setFont(new Font("Tahoma", Font.ITALIC, 16));
		rollno.setBackground(SystemColor.control);
		rollno.setColumns(10);
		rollno.setBounds(895, 265, 370, 50);
		panel.add(rollno);
		
		
		
		
//		private void jTextFieldKeyPressed(java.awt.event.KeyEvent eve)
//		{
		mob = new JTextField();
		mob.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				String s =mob.getText();
				int len=s.length();
				char c =e.getKeyChar();
				if(e.getKeyChar()>='0' && e.getKeyChar()<='9')
				{
					if(len<10 )
					{
						mob.setEditable(true);
					}
					else
					{
						mob.setEditable(false);
					}
				}
				else
				{
					if(e.getExtendedKeyCode()==KeyEvent.VK_BACK_SPACE || e.getExtendedKeyCode()==KeyEvent.VK_DELETE)
					{
						mob.setEditable(true);
					}
					else
					{
						mob.setEditable(false);
					}
				}
			
			}
		});
		mob.setFont(new Font("Tahoma", Font.BOLD, 16));
		mob.setBackground(SystemColor.control);
		mob.setColumns(10);
		mob.setBounds(895, 165, 370, 50);
		panel.add(mob);
		
		pass = new JTextField();
		pass.setFont(new Font("Tahoma", Font.BOLD, 16));
		pass.setBackground(SystemColor.control);
		pass.setColumns(10);
		pass.setBounds(895, 465, 370, 50);
		panel.add(pass);
		
		JLabel lblNewLabel_1_3_1 = new JLabel("Password :");
		lblNewLabel_1_3_1.setForeground(SystemColor.text);
		lblNewLabel_1_3_1.setFont(new Font("Tahoma", Font.PLAIN, 22));
		lblNewLabel_1_3_1.setBounds(713, 470, 158, 35);
		panel.add(lblNewLabel_1_3_1);
		
		final JComboBox Divi = new JComboBox();
		Divi.setModel(new DefaultComboBoxModel(new String[] {"A", "B", "C"}));
		Divi.setBounds(895, 365, 370, 42);
		panel.add(Divi);
		
		final JComboBox cl = new JComboBox();
		cl.setModel(new DefaultComboBoxModel(new String[] {"Computer Engineering", "Mechanical Engineering", "Civil Engineering", "Electronics Enginering"}));
		cl.setBounds(225, 365, 370, 42);
		panel.add(cl);
		
		JButton btnNewButton = new JButton("Submit");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton.setBackground(new Color(0, 204, 0));
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			
				
		         String Pass = pass.getText();
		         String Mob = mob.getText();
		         String Stuid = studid.getText();
		         //int Divi = comboBox.getSelectedIndex();
		         String Address = address.getText();
		        // String Clas = cl.getText();
		         
		         String clas= (String)cl.getSelectedItem();
		         String Name = name.getText();
		         String Division=(String) Divi.getSelectedItem();
		         
		 
//		         if(Divi == 0)
//		         {
//		        	 Division="A"; 
//		         }
//		         else if(Divi ==1)
//		         {
//		        	 Division="B";
//		         }
		         
		         if(pass.getText().length() != 0 && mob.getText().length() != 0 && studid.getText().length()!= 0 && address.getText().length()!= 0 && clas.length()!= -1 && name.getText().length()!= 0  ){
					// creating one object 
		         
			    StudData obj = new StudData();
			    
			    try {
					obj.my_db_update(Name,clas,Address,Division,Stuid,Mob,Pass);
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		         
		         }
		         
		         else {
		        	 JOptionPane.showMessageDialog(null,"Please Enter All Fields");
		         }
		
			}
			
		});
		btnNewButton.setBounds(601, 591, 147, 50);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdminPanel.main(null);
				frame. dispose();
			}
		});
		btnNewButton_1.setForeground(Color.WHITE);
		btnNewButton_1.setBackground(new Color(255, 0, 51));
		btnNewButton_1.setBounds(380, 591, 147, 50);
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_1_1 = new JButton("Reset");
		btnNewButton_1_1.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton_1_1.setForeground(Color.WHITE);
		btnNewButton_1_1.setBackground(new Color(255, 102, 0));
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudData.main(null);
			}
		});
		btnNewButton_1_1.setBounds(823, 591, 147, 50);
		panel.add(btnNewButton_1_1);
		
	
	
		
		//String []div= {"A","B","C","D","E"};
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBackground(new Color(255, 153, 0));
		menuBar.setBounds(0, 0, 1350, 52);
		frame.getContentPane().add(menuBar);
		
		JMenu mnNewMenu = new JMenu("Home");
		mnNewMenu.setFont(new Font("Segoe UI", Font.BOLD, 18));
	
		mnNewMenu.setForeground(Color.WHITE);
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("Edit Student Information");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudUpd.main(null);
			}
		});
		mntmNewMenuItem.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		mnNewMenu.add(mntmNewMenuItem);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("View Student Information");
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudDis.main(null);
			}
		});
		
		JMenuItem mntmNewMenuItem_3 = new JMenuItem("Delete Student Data");
		mntmNewMenuItem_3.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		mntmNewMenuItem_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudDel.main(null);
			}
			
		});
		mnNewMenu.add(mntmNewMenuItem_3);
		mntmNewMenuItem_1.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		mnNewMenu.add(mntmNewMenuItem_1);
		
		JMenuItem mntmNewMenuItem_2 = new JMenuItem("Exit");
		mntmNewMenuItem_2.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		mntmNewMenuItem_2.setIcon(new ImageIcon("D:\\java\\QuizApp\\img\\cross.png"));
		mnNewMenu.add(mntmNewMenuItem_2);
		mntmNewMenuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdminPanel.main(null);
			}
		});
		
	
	
		   
		   }
	}
