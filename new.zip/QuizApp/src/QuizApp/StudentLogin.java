package QuizApp;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import com.mysql.jdbc.JDBC4ResultSet;
import com.mysql.jdbc.PreparedStatement;
import javax.swing.SpringLayout;
import javax.swing.JSeparator;

public class StudentLogin {  
	private JFrame frame;

	private JTextField id;
	private JPasswordField pass;
	
	
	/**
	 * Launch the application.
	 */
	 
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentLogin window = new StudentLogin();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public StudentLogin() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */

		
		private void initialize() {
			
			frame = new JFrame("Student Login");
			frame.setIconImage(Toolkit.getDefaultToolkit().getImage("F:\\Java Project\\QuizApp\\img\\Student.png"));
			Toolkit kit = Toolkit.getDefaultToolkit();
		   
			Dimension screenSize=kit.getScreenSize();
			int screenWidth = screenSize.width;
			int screenHeight = screenSize.height;

			frame.setSize(screenWidth/2,screenHeight/2);
			frame.setLocationRelativeTo(null);
		
			frame.setResizable(false);
			
			frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			SpringLayout springLayout = new SpringLayout();
			frame.getContentPane().setLayout(springLayout);
			
			JPanel panel = new JPanel();
			springLayout.putConstraint(SpringLayout.NORTH, panel, 0, SpringLayout.NORTH, frame.getContentPane());
			springLayout.putConstraint(SpringLayout.WEST, panel, 0, SpringLayout.WEST, frame.getContentPane());
			springLayout.putConstraint(SpringLayout.SOUTH, panel, 355, SpringLayout.NORTH, frame.getContentPane());
			springLayout.putConstraint(SpringLayout.EAST, panel, 677, SpringLayout.WEST, frame.getContentPane());
			panel.setBackground(Color.WHITE);
			frame.getContentPane().add(panel);
			panel.setLayout(null);
			
			JLabel lblNewLabel = new JLabel("");
			lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel.setIcon(new ImageIcon("F:\\Java Project\\QuizApp\\img\\logoDpu1.png"));
			lblNewLabel.setBounds(0, 0, 326, 355);
			panel.add(lblNewLabel);
			panel.setLayout(null);
			
			JLabel lblNewLabel_2 = new JLabel("ID :");
			lblNewLabel_2.setFont(new Font("Arial", Font.PLAIN, 14));
			lblNewLabel_2.setBounds(367, 107, 61, 14);
			panel.add(lblNewLabel_2);
			
			JLabel lblNewLabel_2_1 = new JLabel("Password :");
			lblNewLabel_2_1.setFont(new Font("Arial", Font.PLAIN, 14));
			lblNewLabel_2_1.setBounds(366, 164, 72, 14);
			panel.add(lblNewLabel_2_1);
			
			pass = new JPasswordField();
			lblNewLabel_2_1.setLabelFor(pass);
			pass.setBounds(448, 157, 187, 30);
			panel.add(pass);
			
			JButton btnNewButton = new JButton("LOGIN");
			btnNewButton.setBackground(new Color(51, 51, 204));
			btnNewButton.setFont(new Font("Segoe UI Semibold", Font.PLAIN, 11));
			btnNewButton.setForeground(Color.WHITE);
			btnNewButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					
					StudentLogin s1=new StudentLogin();
					
					 try {
							Class.forName("com.mysql.jdbc.Driver");
						} catch (ClassNotFoundException e1) {
							// TODO Auto-generated catch block
							e1.printStackTrace();
						}
						 Connection conn = null;
					     Statement st = null;
						   try {
							conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/quizapp","root","");
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
						   try {
							st = (Statement) conn.createStatement();
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						   
		            String sql = " SELECT StudentId , Pass  FROM  studinfo ";
		            
		     
						
		     	   
				   ResultSet rs = null;
					try {
						rs = (ResultSet) st.executeQuery(sql);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
			
					String StudentId=null;
					String Pass=null;
				   try {
					while(rs.next()){
						
						StudentId=rs.getString(1);
						Pass=rs.getString(2);
						 
						
					
					   }
					
					
					
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
					   
				   String Id = id.getText();
				   String Pass1 = pass.getText();
				   

				    if(Id.equals(StudentId) && Pass1.equals(Pass) ) {
				    	
				    	TestWindow.main(Id);
				    	
				    }else {
				    	JOptionPane.showMessageDialog(null,"Invalid Login");
				    }	   
					   
					   
					   
					   
				}
			});
			btnNewButton.setBounds(448, 225, 187, 31);
			panel.add(btnNewButton);
			
			id = new JTextField();
			lblNewLabel_2.setLabelFor(id);
			id.setBounds(448, 100, 187, 30);
			panel.add(id);
			id.setColumns(10);
			
			JLabel lblNewLabel_3 = new JLabel("STUDENT LOGIN");
			lblNewLabel_3.setFont(new Font("Arial Black", Font.BOLD, 18));
			lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
			lblNewLabel_3.setBounds(325, 39, 342, 31);
			panel.add(lblNewLabel_3);
			
			JLabel lblNewLabel_4 = new JLabel("(if you don't have id or password then contact your \r\ncollege authority)*");
			lblNewLabel_4.setForeground(new Color(255, 0, 0));
			lblNewLabel_4.setFont(new Font("Arial Unicode MS", Font.ITALIC, 9));
			lblNewLabel_4.setBounds(355, 279, 312, 30);
			panel.add(lblNewLabel_4);
			
			JSeparator separator = new JSeparator();
			separator.setOrientation(SwingConstants.VERTICAL);
			separator.setBackground(Color.BLACK);
			separator.setForeground(Color.BLACK);
			separator.setBounds(325, 23, 1, 300);
			panel.add(separator);
		}

	protected void uname1(String string) {
		// TODO Auto-generated method stub
		
	}

	protected void Pass(String string) {
		// TODO Auto-generated method stub
		
	}
}
