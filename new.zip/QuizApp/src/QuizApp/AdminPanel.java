package QuizApp;

import java.awt.Dimension;
import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Toolkit;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.ImageIcon;
import javax.swing.UIManager;
import javax.swing.JLabel;
import java.awt.BorderLayout;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.SystemColor;
import javax.swing.SpringLayout;

public class AdminPanel {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminPanel window = new AdminPanel();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AdminPanel() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Admin Dashboard");
		frame.getContentPane().setBackground(UIManager.getColor("Button.highlight"));
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(0, 52, 1350, 677);
		frame.getContentPane().add(panel);
		
		JButton btnNewButton = new JButton("");
		btnNewButton.setBackground(new Color(255, 255, 255));
		btnNewButton.setIcon(new ImageIcon("F:\\Java Project\\QuizApp\\img\\AddStud.png"));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudData.main(null);
			}
		});
		SpringLayout sl_panel = new SpringLayout();
		sl_panel.putConstraint(SpringLayout.WEST, btnNewButton, 181, SpringLayout.WEST, panel);
		sl_panel.putConstraint(SpringLayout.EAST, btnNewButton, 426, SpringLayout.WEST, panel);
		panel.setLayout(sl_panel);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("");
		sl_panel.putConstraint(SpringLayout.NORTH, btnNewButton_1, 63, SpringLayout.SOUTH, btnNewButton);
		sl_panel.putConstraint(SpringLayout.WEST, btnNewButton_1, 181, SpringLayout.WEST, panel);
		sl_panel.putConstraint(SpringLayout.SOUTH, btnNewButton_1, -165, SpringLayout.SOUTH, panel);
		btnNewButton_1.setIcon(new ImageIcon("F:\\Java Project\\QuizApp\\img\\AddExam.png"));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				ExamPanel.main(null);
			}
		});
		panel.add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("");
		sl_panel.putConstraint(SpringLayout.EAST, btnNewButton_1, -127, SpringLayout.WEST, btnNewButton_2);
		sl_panel.putConstraint(SpringLayout.SOUTH, btnNewButton_2, -165, SpringLayout.SOUTH, panel);
		sl_panel.putConstraint(SpringLayout.WEST, btnNewButton_2, 553, SpringLayout.WEST, panel);
		btnNewButton_2.setIcon(new ImageIcon("F:\\Java Project\\QuizApp\\img\\Result.png"));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				ResultDIs.main(null);
				
			}
		});
		panel.add(btnNewButton_2);
		
		JButton DelStud = new JButton("");
		sl_panel.putConstraint(SpringLayout.NORTH, btnNewButton, 0, SpringLayout.NORTH, DelStud);
		sl_panel.putConstraint(SpringLayout.SOUTH, btnNewButton, 0, SpringLayout.SOUTH, DelStud);
		sl_panel.putConstraint(SpringLayout.NORTH, DelStud, 63, SpringLayout.NORTH, panel);
		sl_panel.putConstraint(SpringLayout.SOUTH, DelStud, -421, SpringLayout.SOUTH, panel);
		sl_panel.putConstraint(SpringLayout.EAST, DelStud, -178, SpringLayout.EAST, panel);
		DelStud.setIcon(new ImageIcon("F:\\Java Project\\QuizApp\\img\\DelStud.png"));
		DelStud.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudDel.main(null);
			}
		});
		panel.add(DelStud);
		
		JButton EditStud = new JButton("");
		sl_panel.putConstraint(SpringLayout.WEST, DelStud, 129, SpringLayout.EAST, EditStud);
		sl_panel.putConstraint(SpringLayout.NORTH, btnNewButton_2, 63, SpringLayout.SOUTH, EditStud);
		sl_panel.putConstraint(SpringLayout.SOUTH, EditStud, -421, SpringLayout.SOUTH, panel);
		sl_panel.putConstraint(SpringLayout.NORTH, EditStud, 63, SpringLayout.NORTH, panel);
		sl_panel.putConstraint(SpringLayout.EAST, btnNewButton_2, 0, SpringLayout.EAST, EditStud);
		sl_panel.putConstraint(SpringLayout.EAST, EditStud, -552, SpringLayout.EAST, panel);
		sl_panel.putConstraint(SpringLayout.WEST, EditStud, 553, SpringLayout.WEST, panel);
		EditStud.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudUpd.main(null);
			}
		});
		EditStud.setIcon(new ImageIcon("F:\\Java Project\\QuizApp\\img\\EditStud.png"));
		panel.add(EditStud);
		
		JButton btnNewButton_6 = new JButton("Back");
		sl_panel.putConstraint(SpringLayout.NORTH, btnNewButton_6, 68, SpringLayout.SOUTH, btnNewButton_2);
		sl_panel.putConstraint(SpringLayout.WEST, btnNewButton_6, 598, SpringLayout.WEST, panel);
		sl_panel.putConstraint(SpringLayout.SOUTH, btnNewButton_6, -47, SpringLayout.SOUTH, panel);
		sl_panel.putConstraint(SpringLayout.EAST, btnNewButton_6, -593, SpringLayout.EAST, panel);
		btnNewButton_6.setBackground(SystemColor.textHighlight);
		btnNewButton_6.setForeground(Color.WHITE);
		btnNewButton_6.setFont(new Font("Tahoma", Font.BOLD, 16));
		btnNewButton_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				frame. dispose();
				AdminLogin.main(null);
				
			}
		});
		panel.add(btnNewButton_6);
		
		JButton DisStud = new JButton("");
		sl_panel.putConstraint(SpringLayout.NORTH, DisStud, 0, SpringLayout.NORTH, btnNewButton_1);
		sl_panel.putConstraint(SpringLayout.WEST, DisStud, 0, SpringLayout.WEST, DelStud);
		sl_panel.putConstraint(SpringLayout.SOUTH, DisStud, 0, SpringLayout.SOUTH, btnNewButton_1);
		sl_panel.putConstraint(SpringLayout.EAST, DisStud, 0, SpringLayout.EAST, DelStud);
		DisStud.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudDis.main(null);
			}
		});
		DisStud.setIcon(new ImageIcon("F:\\Java Project\\QuizApp\\img\\ViewStud.png"));
		panel.add(DisStud);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 1522, 52);
		frame.getContentPane().add(menuBar);
		menuBar.setFont(new Font("Segoe UI", Font.PLAIN, 18));
		menuBar.setForeground(new Color(255, 255, 255));
		menuBar.setBackground(SystemColor.textHighlight);
		
		JMenu mnNewMenu = new JMenu("Home");
		mnNewMenu.setFont(new Font("Segoe UI", Font.BOLD, 14));
		mnNewMenu.setHorizontalAlignment(SwingConstants.CENTER);
		mnNewMenu.setForeground(new Color(255, 255, 255));
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("Exit");
		mntmNewMenuItem.setSelectedIcon(null);
		mntmNewMenuItem.setIcon(new ImageIcon("F:\\Java Project\\QuizApp\\img\\cross.png"));
		mntmNewMenuItem.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		mntmNewMenuItem.setHorizontalAlignment(SwingConstants.CENTER);
		mntmNewMenuItem.setBackground(new Color(255, 255, 255));
		mnNewMenu.add(mntmNewMenuItem);
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				frame. dispose();
				AdminLogin.main(null);
			
			}
		});
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("F:\\Java Project\\QuizApp\\img\\AdminLogin.png"));
	    Toolkit kit = Toolkit.getDefaultToolkit();
		Dimension screenSize=kit.getScreenSize();
		int screenWidth = screenSize.width;
		int screenHeight = screenSize.height;

		frame.setSize(screenWidth,screenHeight);
		
		frame.setLocationRelativeTo(null);
		
		frame.setResizable(true);
		
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
