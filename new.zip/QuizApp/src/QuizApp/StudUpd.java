package QuizApp;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.jar.Attributes.Name;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

public class StudUpd {

	private JFrame frame;
	private JTextField RollNo;
	private JTextField mob;
	private JTextField pass;
	private JTextField studid;
	private JComponent div;
	private JTextField cl;
	private JTextField address;
	private JComponent name;
	private JTextField studname;
	private JTextField txtDiv;
    
	
	void update(int rollno1,String Name,String Clas,String Address,String Divi,String Stuid,String Mob,String Pass) throws ClassNotFoundException {

		 Class.forName("com.mysql.jdbc.Driver");
		 Connection conn = null;
	     Statement stmt = null;
		   try {
			conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/quizapp","root","");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		   
	     try {
			stmt = (Statement) conn.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	     
	    String sql="UPDATE studinfo SET Name = '"+Name+"' , Address = '"+Address+"' ,Class ='" +Clas+ "',StudentId='" + Stuid + "',Pass ='" +Pass+ "',Divi ='" +Divi+ "',MobNo ='" +Mob+ "' WHERE RollNo = " + rollno1+" ";
		
	    try {
			 
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		 
	    
		 JOptionPane.showMessageDialog(null,"Data Updated Sucessfully");
		        frame. dispose();
			StudUpd window = new StudUpd();
			window.frame .setVisible(true);
		
	}
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudUpd window = new StudUpd();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public StudUpd() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Edit Student Data");
		
		frame.setIconImage(Toolkit.getDefaultToolkit().getImage("O:\\java assignment\\QuizApp\\img\\male-user-edit_25348.png"));
		frame.setBounds(0, 54, 1350, 675);
		Toolkit kit = Toolkit.getDefaultToolkit();
		Dimension screenSize=kit.getScreenSize();
		int screenWidth = screenSize.width;
		int screenHeight = screenSize.height;

		frame.setSize(screenWidth,screenHeight);
		frame.setLocationRelativeTo(null);
	
		frame.setResizable(false);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(102, 51, 102));
		panel.setBounds(0, 0, 1350, 729);
		frame.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Update Student Data");
		lblNewLabel.setForeground(SystemColor.text);
		lblNewLabel.setFont(new Font("Microsoft YaHei", Font.BOLD, 24));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(0, 76, 1350, 41);
		panel.add(lblNewLabel);
		

		JLabel lblNewLabel_1 = new JLabel("Name :");
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1.setBounds(85, 276, 104, 35);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Address :");
		lblNewLabel_1_1.setForeground(SystemColor.text);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_1.setBounds(85, 376, 104, 35);
		panel.add(lblNewLabel_1_1);
		
		JLabel lblNewLabel_1_2 = new JLabel("Class :");
		lblNewLabel_1_2.setForeground(SystemColor.text);
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_2.setBounds(85, 476, 104, 35);
		panel.add(lblNewLabel_1_2);
		
		JLabel lblNewLabel_1_3 = new JLabel("Division :");
		lblNewLabel_1_3.setForeground(SystemColor.text);
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_3.setBounds(728, 376, 104, 35);
		panel.add(lblNewLabel_1_3);
		
		JLabel lblNewLabel_1_4 = new JLabel("Student Id :");
		lblNewLabel_1_4.setForeground(SystemColor.text);
		lblNewLabel_1_4.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_4.setBounds(85, 576, 104, 35);
		panel.add(lblNewLabel_1_4);
		
		
		
		address = new JTextField();
		address.setFont(new Font("Tahoma", Font.BOLD, 16));
		address.setBackground(SystemColor.control);
		address.setColumns(10);
		address.setBounds(283, 382, 370, 45);
		panel.add(address);
		
		cl = new JTextField();
		cl.setFont(new Font("Tahoma", Font.BOLD, 16));
		cl.setBackground(SystemColor.control);
		cl.setColumns(10);
		cl.setBounds(283, 482, 370, 45);
		panel.add(cl);
		
	
		
		studid = new JTextField();
		studid.setFont(new Font("Tahoma", Font.BOLD, 16));
		studid.setBackground(SystemColor.control);
		studid.setColumns(10);
		studid.setBounds(283, 582, 370, 45);
		panel.add(studid);
		
		JLabel lblNewLabel_1_5 = new JLabel("Roll Number :");
		lblNewLabel_1_5.setForeground(SystemColor.text);
		lblNewLabel_1_5.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_5.setBounds(283, 160, 139, 35);
		panel.add(lblNewLabel_1_5);
		
		mob = new JTextField();
		mob.setFont(new Font("Tahoma", Font.BOLD, 16));
		mob.setBackground(SystemColor.control);
		mob.setColumns(10);
		mob.setBounds(895, 272, 370, 45);
		panel.add(mob);
		
		pass = new JTextField();
		pass.setFont(new Font("Tahoma", Font.BOLD, 16));
		pass.setBackground(SystemColor.control);
		pass.setColumns(10);
		pass.setBounds(895, 472, 370, 45);
		panel.add(pass);
		
		JLabel lblNewLabel_1_3_1 = new JLabel("Password :");
		lblNewLabel_1_3_1.setForeground(SystemColor.text);
		lblNewLabel_1_3_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_3_1.setBounds(728, 476, 104, 35);
		panel.add(lblNewLabel_1_3_1);
		
		
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBackground(new Color(255, 153, 0));
		menuBar.setBounds(0, 0, 1350, 52);
		panel.add(menuBar);
		
		
		
		
		JMenu mnNewMenu = new JMenu("Home");
		mnNewMenu.setFont(new Font("Segoe UI", Font.BOLD, 18));
		mnNewMenu.setHorizontalAlignment(SwingConstants.CENTER);
		mnNewMenu.setForeground(new Color(255, 255, 255));
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmNewMenuItem3 = new JMenuItem("Add Student Information");
		mntmNewMenuItem3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudData.main(null);
			}
		});
		mntmNewMenuItem3.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		mnNewMenu.add(mntmNewMenuItem3);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("Delete Student Information");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudDel.main(null);
			}
		});
		mntmNewMenuItem.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		mnNewMenu.add(mntmNewMenuItem);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("View Student Information");
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudDis.main(null);
			}
		});
		mntmNewMenuItem_1.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		mnNewMenu.add(mntmNewMenuItem_1);
		
	
		
		JMenuItem mntmNewMenuItem_2 = new JMenuItem("Exit");
		mntmNewMenuItem_2.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		mntmNewMenuItem_2.setIcon(new ImageIcon("O:\\java assignment\\QuizApp\\img\\cross.png"));
		mnNewMenu.add(mntmNewMenuItem_2);
		mntmNewMenuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdminPanel.main(null);
			}
		});
		
		
		JButton btnNewButton = new JButton("Update");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				 String Pass = pass.getText();
		         String Mob = mob.getText();
		         String Stuid = studid.getText();
		         String Divi = txtDiv.getText();
		         String Address = address.getText();
		         String Clas = cl.getText();
		         String Name = studname.getText();
		         String rollno = RollNo.getText();
					
		         if(pass.getText().length() != 0 && mob.getText().length() != 0 && studid.getText().length()!= 0 && txtDiv.getText().length()!= 0 && address.getText().length()!= 0 && cl.getText().length()!= 0 && studname.getText().length()!= 0  ){
						
				  StudUpd obj = new StudUpd();
				    
				  int rollno1 =Integer.parseInt(rollno);
				
				  try {
					obj.update(rollno1,Name,Clas,Address,Divi,Stuid,Mob,Pass);
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
                }
		         
		         else {
		        	 JOptionPane.showMessageDialog(null,"Please Enter All Fields");
		         }
		
		       
					// creating one object 
		        
			    
			
			}
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(51, 204, 0));
		btnNewButton.setBounds(582, 673, 180, 45);
		panel.add(btnNewButton);
		
		RollNo = new JTextField();
		RollNo.setBounds(432, 160, 409, 41);
		panel.add(RollNo);
		RollNo.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_1.setBackground(new Color(255, 0, 51));
		btnNewButton_1.setForeground(SystemColor.text);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AdminPanel.main(null);
				frame. dispose();
			}
		});
		btnNewButton_1.setBounds(362, 673, 180, 45);
		panel.add(btnNewButton_1);
		

		
		JButton btnReset = new JButton("Reset");
		btnReset.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudUpd window = new StudUpd();
				window.frame.setVisible(true);
			}
		});
		btnReset.setForeground(Color.WHITE);
		btnReset.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnReset.setBackground(new Color(255, 153, 51));
		btnReset.setBounds(800, 673, 180, 45);
		panel.add(btnReset);
		
		JLabel lblNewLabel_1_3_2 = new JLabel("Mobile No :");
		lblNewLabel_1_3_2.setForeground(Color.WHITE);
		lblNewLabel_1_3_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_3_2.setBounds(728, 276, 104, 35);
		panel.add(lblNewLabel_1_3_2);
		
		studname = new JTextField();
		studname.setFont(new Font("Tahoma", Font.BOLD, 16));
		studname.setColumns(10);
		studname.setBackground(SystemColor.menu);
		studname.setBounds(283, 272, 370, 45);
		panel.add(studname);
		
		txtDiv = new JTextField();
		txtDiv.setFont(new Font("Tahoma", Font.BOLD, 16));
		txtDiv.setColumns(10);
		txtDiv.setBackground(SystemColor.menu);
		txtDiv.setBounds(895, 372, 370, 45);
		panel.add(txtDiv);
		
		JButton btnNewButton_1_1 = new JButton("Search");
		btnNewButton_1_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				 try {
						Class.forName("com.mysql.jdbc.Driver");
					} catch (ClassNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					 Connection conn = null;
				     Statement st = null;
					   try {
						conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/quizapp","root","");
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					   try {
						st = (Statement) conn.createStatement();
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					   String rollno = RollNo.getText();
					   String sql ="select Name , Address, Class, StudentId, Pass, Divi, MobNo FROM studinfo Where RollNo="+rollno;
				
						   
						ResultSet rs = null;
						try {
							rs = st.executeQuery(sql);
						} catch (SQLException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
				
						
					   try {
						while(rs.next()) {
						
							studname.setText(rs.getString(1));
							
							address.setText(rs.getString(2));
							
							cl.setText(rs.getString(3));
				
							studid.setText(rs.getString(4));
							pass.setText(rs.getString(5));
							txtDiv.setText(rs.getString(6));
						    mob.setText(rs.getString(7));
						    
						   }
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
			
			
			
			
			}
		});
		btnNewButton_1_1.setForeground(Color.WHITE);
		btnNewButton_1_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_1_1.setBackground(SystemColor.textHighlight);
		btnNewButton_1_1.setBounds(895, 158, 177, 41);
		panel.add(btnNewButton_1_1);
	}
}
