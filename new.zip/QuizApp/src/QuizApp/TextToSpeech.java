package QuizApp;
//
//******************************************************************************************************************************

/* Java code to convert text to speech. It is used in student module. So don't remove this file. (31/03/2023)  */


//****************************************************************************************************************************
import com.sun.speech.freetts.Voice;
import com.sun.speech.freetts.VoiceManager;



public class TextToSpeech {
    
	public void Speack(String Speack) {
		System.setProperty("freetts.voices", "com.sun.speech.freetts.en.us.cmu_us_kal.KevinVoiceDirectory");
	    Voice voice = VoiceManager.getInstance().getVoice("kevin16");
	    if (voice != null) {
	        voice.allocate();// Allocating Voice
	        try {
	            voice.setRate(120);// Setting the rate of the voice
	            voice.setPitch(120);// Setting the Pitch of the voice
	            voice.setVolume(8);// Setting the volume of the voice
	            voice.speak(Speack);// Calling speak() method

	        } catch (Exception e1) {
	            e1.printStackTrace();
	        }

	    } else {
	        throw new IllegalStateException("Cannot find voice: kevin16");
	    }
		
	}
	public static void main(String[] args)
	{
         
		
 		    
	}

	
}


