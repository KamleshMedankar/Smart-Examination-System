package QuizApp;

import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.SystemColor;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.SpringLayout;

public class EndExam {

	private JFrame frame;
	static int Result;
     
	static String Id1=null;
	/**
	 * Launch the application.
	 * @throws SQLException 
	 * @throws ClassNotFoundException 
	 */
	public static void main(int resultsum,String Id) throws SQLException, ClassNotFoundException {
		Result=resultsum;
		Id1=Id;
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EndExam window = new EndExam();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		
		
		JLabel jLabel = new JLabel();
		jLabel.setText("dsf");
		
		 		
		
		
		 
		 Class.forName("com.mysql.jdbc.Driver");
		 Connection conn = null;
	     Statement stmt = null;
		   try {
			conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/quizapp","root","");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		   
	     try {
			stmt = (Statement) conn.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 String sql = "INSERT INTO `result`(`ExamID`, `Score`)"+" values('"+Id1+"',"+Result+")";
		 try {
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		 
		
	}

	/**
	 * Create the application.
	 */
	public EndExam() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		
		
		
		
		
		frame = new JFrame();
		
		
		Toolkit kit = Toolkit.getDefaultToolkit();
		Dimension screenSize=kit.getScreenSize();
		int screenWidth = screenSize.width;
		int screenHeight = screenSize.height;

	    frame.setSize(screenWidth,screenHeight);
		frame.setLocationRelativeTo(null);
	
		frame.setResizable(false);
	
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		SpringLayout springLayout = new SpringLayout();
		frame.getContentPane().setLayout(springLayout);
		
		JPanel panel = new JPanel();
		springLayout.putConstraint(SpringLayout.NORTH, panel, 0, SpringLayout.NORTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.WEST, panel, 0, SpringLayout.WEST, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.SOUTH, panel, 0, SpringLayout.SOUTH, frame.getContentPane());
		springLayout.putConstraint(SpringLayout.EAST, panel, 1360, SpringLayout.WEST, frame.getContentPane());
		panel.setBackground(new Color(51, 51, 51));
		frame.getContentPane().add(panel);
		SpringLayout sl_panel = new SpringLayout();
		panel.setLayout(sl_panel);
		
		JPanel panel_1 = new JPanel();
		sl_panel.putConstraint(SpringLayout.NORTH, panel_1, 130, SpringLayout.NORTH, panel);
		sl_panel.putConstraint(SpringLayout.WEST, panel_1, 347, SpringLayout.WEST, panel);
		sl_panel.putConstraint(SpringLayout.SOUTH, panel_1, -91, SpringLayout.SOUTH, panel);
		sl_panel.putConstraint(SpringLayout.EAST, panel_1, -342, SpringLayout.EAST, panel);
		panel_1.setBorder(new SoftBevelBorder(BevelBorder.RAISED, null, null, null, null));
		panel.add(panel_1);
		SpringLayout sl_panel_1 = new SpringLayout();
		panel_1.setLayout(sl_panel_1);
		
		JLabel lblNewLabel = new JLabel("Your Exam Was Submitted Successfully...");
		sl_panel_1.putConstraint(SpringLayout.NORTH, lblNewLabel, 11, SpringLayout.NORTH, panel_1);
		sl_panel_1.putConstraint(SpringLayout.WEST, lblNewLabel, 0, SpringLayout.WEST, panel_1);
		sl_panel_1.putConstraint(SpringLayout.SOUTH, lblNewLabel, 70, SpringLayout.NORTH, panel_1);
		sl_panel_1.putConstraint(SpringLayout.EAST, lblNewLabel, 656, SpringLayout.WEST, panel_1);
		lblNewLabel.setForeground(new Color(0, 0, 0));
		lblNewLabel.setBackground(new Color(255, 153, 0));
		panel_1.add(lblNewLabel);
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 24));
		
		JLabel Result1 = new JLabel("");
		sl_panel_1.putConstraint(SpringLayout.NORTH, Result1, 384, SpringLayout.NORTH, panel_1);
		sl_panel_1.putConstraint(SpringLayout.WEST, Result1, 311, SpringLayout.WEST, panel_1);
		sl_panel_1.putConstraint(SpringLayout.SOUTH, Result1, 448, SpringLayout.NORTH, panel_1);
		sl_panel_1.putConstraint(SpringLayout.EAST, Result1, 526, SpringLayout.WEST, panel_1);
		panel_1.add(Result1);
		Result1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		Result1.setHorizontalAlignment(SwingConstants.CENTER);
		Result1.setText(String.valueOf(Result));
		
		JLabel lblResult = new JLabel("Score = ");
		sl_panel_1.putConstraint(SpringLayout.NORTH, lblResult, 20, SpringLayout.NORTH, Result1);
		sl_panel_1.putConstraint(SpringLayout.EAST, lblResult, 299, SpringLayout.WEST, panel_1);
		panel_1.add(lblResult);
		lblResult.setFont(new Font("Tahoma", Font.PLAIN, 18));
		
		JLabel id = new JLabel("Your Exam ID = ");
		sl_panel_1.putConstraint(SpringLayout.WEST, lblResult, 0, SpringLayout.WEST, id);
		sl_panel_1.putConstraint(SpringLayout.WEST, id, 138, SpringLayout.WEST, panel_1);
		sl_panel_1.putConstraint(SpringLayout.SOUTH, id, 355, SpringLayout.NORTH, panel_1);
		panel_1.add(id);
		id.setFont(new Font("Tahoma", Font.PLAIN, 18));
		
		JLabel id1 = new JLabel("");
		sl_panel_1.putConstraint(SpringLayout.EAST, id, -12, SpringLayout.WEST, id1);
		sl_panel_1.putConstraint(SpringLayout.NORTH, id1, 306, SpringLayout.NORTH, panel_1);
		sl_panel_1.putConstraint(SpringLayout.WEST, id1, 311, SpringLayout.WEST, panel_1);
		sl_panel_1.putConstraint(SpringLayout.SOUTH, id1, 370, SpringLayout.NORTH, panel_1);
		sl_panel_1.putConstraint(SpringLayout.EAST, id1, 526, SpringLayout.WEST, panel_1);
		panel_1.add(id1);
		id1.setHorizontalAlignment(SwingConstants.CENTER);
		id1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		
		id1.setText(Id1);
		
		JLabel lblNewLabel_1 = new JLabel("");
		sl_panel_1.putConstraint(SpringLayout.NORTH, id, 35, SpringLayout.SOUTH, lblNewLabel_1);
		sl_panel_1.putConstraint(SpringLayout.NORTH, lblNewLabel_1, 88, SpringLayout.NORTH, panel_1);
		sl_panel_1.putConstraint(SpringLayout.WEST, lblNewLabel_1, 0, SpringLayout.WEST, panel_1);
		sl_panel_1.putConstraint(SpringLayout.SOUTH, lblNewLabel_1, -11, SpringLayout.NORTH, id1);
		sl_panel_1.putConstraint(SpringLayout.EAST, lblNewLabel_1, 657, SpringLayout.WEST, panel_1);
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setIcon(new ImageIcon("F:\\Java Project\\QuizApp\\img\\ok.png"));
		panel_1.add(lblNewLabel_1);
		
		
		
		
		
	}


}
