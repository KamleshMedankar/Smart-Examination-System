package QuizApp;
// ******************************************************************************************************************************

/* This page is not Linking ,updated version of this page is TestWindow (31/03/2023)  */


//****************************************************************************************************************************
import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Collections;
import java.util.Random;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JTextPane;
import javax.swing.SwingConstants;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import javax.swing.SpringLayout;

public class Examf {

	private JFrame frmExampanel;
	private JRadioButton B;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JTextPane Que;
	private JRadioButton C;
	private JRadioButton A;
	private JRadioButton D;

	int result=0;
	int resultsum=0;
	int r;
    int i=1;
    String Ans1;
    String Ans;
    
   static String Id=null;
	/**
	 * Launch the application.
	 */
	public static void main(String id) {
		
		
		Id=id;
		
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Examf window = new Examf();
					window.frmExampanel.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
		

		
	}

	/**
	 * Create the application.
	 * @wbp.parser.entryPoint
	 */
	public Examf() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
private void initialize() {
		
        i++;
	    frmExampanel = new JFrame();
	    frmExampanel.setTitle("ExamPanel");
	    frmExampanel.setIconImage(Toolkit.getDefaultToolkit().getImage("O:\\java assignment\\QuizApp\\img\\Student.png"));
		frmExampanel.setBounds(100, 100, 450, 300);
		frmExampanel.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		Toolkit kit = Toolkit.getDefaultToolkit();
		Dimension screenSize=kit.getScreenSize();
		int screenWidth = screenSize.width;

		int screenHeight = screenSize.height;
		frmExampanel.setSize(screenWidth,screenHeight);
		frmExampanel.setLocationRelativeTo(null);
		frmExampanel.setResizable(false);

		frmExampanel.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmExampanel.getContentPane().setLayout(null);
		
		final JPanel panel_2 = new JPanel();
		panel_2.setBackground(new Color(0, 204, 102));
		panel_2.setBounds(0, 0, 1350, 571);
		frmExampanel.getContentPane().add(panel_2);
		SpringLayout sl_panel_2 = new SpringLayout();
		panel_2.setLayout(sl_panel_2);
		
		JLabel lblNewLabel_2 = new JLabel("Exam Instructions");
		sl_panel_2.putConstraint(SpringLayout.NORTH, lblNewLabel_2, 31, SpringLayout.NORTH, panel_2);
		sl_panel_2.putConstraint(SpringLayout.WEST, lblNewLabel_2, 0, SpringLayout.WEST, panel_2);
		sl_panel_2.putConstraint(SpringLayout.SOUTH, lblNewLabel_2, 102, SpringLayout.NORTH, panel_2);
		sl_panel_2.putConstraint(SpringLayout.EAST, lblNewLabel_2, 1350, SpringLayout.WEST, panel_2);
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setForeground(Color.WHITE);
		lblNewLabel_2.setFont(new Font("Tahoma", Font.BOLD, 28));
		panel_2.add(lblNewLabel_2);
		
		JPanel panel_3 = new JPanel();
		sl_panel_2.putConstraint(SpringLayout.NORTH, panel_3, 103, SpringLayout.NORTH, panel_2);
		sl_panel_2.putConstraint(SpringLayout.WEST, panel_3, 50, SpringLayout.WEST, panel_2);
		sl_panel_2.putConstraint(SpringLayout.SOUTH, panel_3, 464, SpringLayout.NORTH, panel_2);
		sl_panel_2.putConstraint(SpringLayout.EAST, panel_3, 1300, SpringLayout.WEST, panel_2);
		panel_3.setLayout(null);
		panel_3.setBorder(new SoftBevelBorder(BevelBorder.LOWERED, null, null, null, null));
		panel_3.setBackground(Color.WHITE);
		panel_2.add(panel_3);
		
		JLabel lblNewLabel_3 = new JLabel("* There is !5 Question .");
		lblNewLabel_3.setFont(new Font("Times New Roman", Font.ITALIC, 15));
		lblNewLabel_3.setBounds(46, 22, 1143, 35);
		panel_3.add(lblNewLabel_3);
		
		JLabel lblNewLabel_3_1 = new JLabel("* Attempt all question .");
		lblNewLabel_3_1.setFont(new Font("Times New Roman", Font.ITALIC, 15));
		lblNewLabel_3_1.setBounds(46, 67, 1143, 35);
		panel_3.add(lblNewLabel_3_1);
		
		JLabel lblNewLabel_3_2 = new JLabel("* No negative marking .");
		lblNewLabel_3_2.setFont(new Font("Times New Roman", Font.ITALIC, 15));
		lblNewLabel_3_2.setBounds(46, 112, 1143, 35);
		panel_3.add(lblNewLabel_3_2);
		
		JLabel lblNewLabel_3_2_1 = new JLabel("* Read all questions carefully , back button is not available .");
		lblNewLabel_3_2_1.setFont(new Font("Times New Roman", Font.ITALIC, 15));
		lblNewLabel_3_2_1.setBounds(46, 148, 1143, 35);
		panel_3.add(lblNewLabel_3_2_1);
		
		JLabel lblNewLabel_3_2_1_1 = new JLabel("* Best of luck .");
		lblNewLabel_3_2_1_1.setFont(new Font("Times New Roman", Font.ITALIC, 15));
		lblNewLabel_3_2_1_1.setBounds(46, 193, 1143, 35);
		panel_3.add(lblNewLabel_3_2_1_1);

		JPanel panel = new JPanel();
		panel.setBackground(Color.WHITE);
		panel.setBounds(0, 0, 1350, 729);
		frmExampanel.getContentPane().add(panel);
		panel.setLayout(null);

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(new Color(0, 204, 102));
		panel_1.setBounds(0, 47, 1522, 250);
		panel.add(panel_1);
		panel_1.setLayout(null);

		JLabel lblNewLabel = new JLabel("Question :");
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 18));
		lblNewLabel.setBounds(123, 102, 113, 38);
		panel_1.add(lblNewLabel);

		Que = new JTextPane();
		Que.setFont(new Font("Tahoma", Font.PLAIN, 14));
		Que.setForeground(new Color(0, 0, 0));
		Que.setBackground(new Color(255, 255, 255));

		Que.setEditable(false);
		Que.setBounds(245, 69, 1053, 114);
		panel_1.add(Que);

		JLabel lblNewLabel_1 = new JLabel("A :");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1.setBounds(183, 373, 46, 14);
		panel.add(lblNewLabel_1);

		JLabel lblNewLabel_1_1 = new JLabel("C :");
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_1.setBounds(183, 521, 46, 14);
		panel.add(lblNewLabel_1_1);

		JLabel lblNewLabel_1_2 = new JLabel("B :");
		lblNewLabel_1_2.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_2.setBounds(905, 384, 46, 14);
		panel.add(lblNewLabel_1_2);

		JLabel lblNewLabel_1_3 = new JLabel("D :");
		lblNewLabel_1_3.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1_3.setBounds(905, 521, 46, 14);
		panel.add(lblNewLabel_1_3);

		A = new JRadioButton();
		A.setEnabled(false);
		A.setBackground(new Color(255, 255, 255));
		A.setFont(new Font("Tahoma", Font.PLAIN, 14));
		buttonGroup.add(A);
		A.setBounds(254, 341, 399, 86);
		A.setActionCommand("1");
		panel.add(A);

		C = new JRadioButton();
		C.setEnabled(false);
		C.setBackground(new Color(255, 255, 255));
		C.setFont(new Font("Tahoma", Font.PLAIN, 14));
		buttonGroup.add(C);
		C.setActionCommand("3");
		C.setBounds(254, 489, 399, 86);
		panel.add(C);

		B = new JRadioButton("");
		B.setEnabled(false);
		B.setBackground(new Color(255, 255, 255));
		B.setFont(new Font("Tahoma", Font.PLAIN, 14));
		buttonGroup.add(B);
		B.setBounds(998, 351, 399, 86);
		B.setActionCommand("2");
		panel.add(B);

		D = new JRadioButton("");
		D.setEnabled(false);
		D.setBackground(new Color(255, 255, 255));
		D.setFont(new Font("Tahoma", Font.PLAIN, 14));
		buttonGroup.add(D);
		D.setBounds(998, 489, 399, 86);
		D.setActionCommand("4");
		panel.add(D);

		JButton btnNewButton = new JButton("Submit");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton.setBackground(SystemColor.textHighlight);
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {				
				panel_2.setBounds(0, 0, 0, 0);
				A.setEnabled(true);
				B.setEnabled(true);
				C.setEnabled(true);
				D.setEnabled(true);
			
				// loop 
				
				
				if(i<16) {

					
				  
				try {
					Class.forName("com.mysql.jdbc.Driver");
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Connection conn = null;
				Statement st = null;
				try {
					conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/quizapp","root","");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				try {
					st = (Statement) conn.createStatement();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
           
				String sql ="SELECT Question, OpA, OpB, OpC, OpD, Ans FROM question order by rand()";
			
				
			
				ResultSet rs = null;
				try {
									
				   rs = st.executeQuery(sql);

					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				 int result=0;
                 i=i+1;
				
				try {
					while(rs.next()){

						Que.setText(rs.getString(1));

						A.setText(rs.getString(2));
						B.setText(rs.getString(3));
						C.setText(rs.getString(4));
						D.setText(rs.getString(5));
						Ans1 = rs.getString(6);
						Ans = buttonGroup.getSelection().getActionCommand();
				        System.out.println(Ans1);
				        System.out.println(Ans);
				       
					}

				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
                 
				 if( Ans.equals(Ans1)) {
			         
			        	resultsum ++ ;
			     	   r=resultsum;
			        }
			        
				System.out.println("result="+ resultsum);
			}
			
			else {	
				try {
					Class.forName("com.mysql.jdbc.Driver");
				} catch (ClassNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				Connection conn = null;
				Statement st = null;
				try {
					conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/quizapp","root","");
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

				try {
					st = (Statement) conn.createStatement();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
		   
				String sql ="INSERT INTO result"+"(`UserId`,'Result')"+" VALUES ('"+Id+"', "+ resultsum +")";
			
				
			
				ResultSet rs = null;
				try {
									
				   rs = st.executeQuery(sql);

					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				try {
					EndExam.main(resultsum,Id);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
			}
			}});

		
		
		btnNewButton.setBounds(597, 625, 159, 52);
		panel.add(btnNewButton);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 1522, 52);
		panel.add(menuBar);
		
		



	
}
}
