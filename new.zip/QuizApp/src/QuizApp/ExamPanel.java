package QuizApp;

import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import java.awt.Color;
import java.awt.SystemColor;
import java.awt.Font;
import javax.swing.JMenuItem;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;

import java.awt.event.ActionListener;
import java.io.File;
import java.awt.event.ActionEvent;
import javax.swing.JSeparator;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.SpringLayout;

public class ExamPanel {

	private JFrame frmAddExam;
	private final JPanel panel = new JPanel();

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ExamPanel window = new ExamPanel();
					window.frmAddExam.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ExamPanel() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmAddExam = new JFrame();
		frmAddExam.setIconImage(Toolkit.getDefaultToolkit().getImage("O:\\java assignment\\QuizApp\\img\\exam_sheet_test_school_study_icon_209289.png"));
		frmAddExam.setTitle("Exam Panel");
		frmAddExam.setBounds(100, 100, 450, 300);
		Toolkit kit = Toolkit.getDefaultToolkit();
		Dimension screenSize=kit.getScreenSize();
		int screenWidth = screenSize.width;
		
		int screenHeight = screenSize.height;
		frmAddExam.setSize(screenWidth,screenHeight);
		frmAddExam.setLocationRelativeTo(null);
		frmAddExam.setResizable(false);
		frmAddExam.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmAddExam.getContentPane().setLayout(null);
		panel.setForeground(new Color(255, 255, 255));
		panel.setBackground(new Color(255, 255, 255));
		panel.setBounds(0, 0, 1350, 729);
		frmAddExam.getContentPane().add(panel);
		
		JButton btnAddEam = new JButton("Add Question Bank");
		btnAddEam.setIcon(new ImageIcon("F:\\Java Project\\QuizApp\\img\\qb2.png"));
		btnAddEam.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnAddEam.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			AddExam.main(null);
			}
		});
		SpringLayout sl_panel = new SpringLayout();
		panel.setLayout(sl_panel);
		btnAddEam.setBackground(SystemColor.text);
		panel.add(btnAddEam);
		
		JButton btnManageTest = new JButton("Manage Question Bank");
		sl_panel.putConstraint(SpringLayout.NORTH, btnAddEam, -4, SpringLayout.NORTH, btnManageTest);
		sl_panel.putConstraint(SpringLayout.SOUTH, btnAddEam, 0, SpringLayout.SOUTH, btnManageTest);
		sl_panel.putConstraint(SpringLayout.EAST, btnAddEam, -166, SpringLayout.WEST, btnManageTest);
		sl_panel.putConstraint(SpringLayout.WEST, btnManageTest, 924, SpringLayout.WEST, panel);
		sl_panel.putConstraint(SpringLayout.EAST, btnManageTest, -181, SpringLayout.EAST, panel);
		btnManageTest.setIcon(new ImageIcon("F:\\Java Project\\QuizApp\\img\\qb.jfif"));
		btnManageTest.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MangeQb.main(null);
			}
		});
		btnManageTest.setFont(new Font("Tahoma", Font.PLAIN, 18));
		btnManageTest.setBackground(Color.WHITE);
		panel.add(btnManageTest);
		
		JPanel panel_1 = new JPanel();
		sl_panel.putConstraint(SpringLayout.NORTH, panel_1, 0, SpringLayout.NORTH, panel);
		sl_panel.putConstraint(SpringLayout.WEST, panel_1, 0, SpringLayout.WEST, panel);
		sl_panel.putConstraint(SpringLayout.SOUTH, panel_1, 729, SpringLayout.NORTH, panel);
		sl_panel.putConstraint(SpringLayout.EAST, panel_1, 300, SpringLayout.WEST, panel);
		panel_1.setBackground(new Color(0, 102, 204));
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JSeparator separator = new JSeparator();
		separator.setBounds(13, 109, 274, 2);
		panel_1.add(separator);
		
		JLabel lblNewLabel = new JLabel("Exam Dashboard");
		lblNewLabel.setFont(new Font("Arial", Font.BOLD, 32));
		lblNewLabel.setForeground(SystemColor.textHighlightText);
		lblNewLabel.setBounds(20, 69, 265, 31);
		panel_1.add(lblNewLabel);
		
		JButton btnNewButton = new JButton("Home");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdminPanel.main(null);
				
				
			}
		});
		btnNewButton.setSelectedIcon(new ImageIcon("O:\\java assignment\\QuizApp\\img\\cross.png"));
		btnNewButton.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
		btnNewButton.setToolTipText("");
		btnNewButton.setBounds(0, 145, 300, 68);
		panel_1.add(btnNewButton);
		btnNewButton.setForeground(Color.WHITE);
		btnNewButton.setBackground(new Color(51, 102, 204));
		
		JButton ASI = new JButton("Active Student Info ");
		ASI.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
		ASI.setBackground(new Color(0, 102, 204));
		ASI.setBounds(0, 212, 300, 68);
		panel_1.add(ASI);
		ASI.setForeground(new Color(255, 255, 255));
		
		JButton btnNewButton_1 = new JButton("LogOut");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				AdminLogin.main(null);
				frmAddExam. dispose();
				
			}
		});
		btnNewButton_1.setFont(new Font("Yu Gothic UI Semibold", Font.PLAIN, 20));
		btnNewButton_1.setBackground(new Color(0, 102, 204));
		btnNewButton_1.setBounds(0, 277, 300, 68);
		panel_1.add(btnNewButton_1);
		btnNewButton_1.setForeground(new Color(255, 255, 255));
		
		JPanel panel_2 = new JPanel();
		sl_panel.putConstraint(SpringLayout.NORTH, btnManageTest, 208, SpringLayout.SOUTH, panel_2);
		sl_panel.putConstraint(SpringLayout.NORTH, panel_2, 0, SpringLayout.NORTH, panel);
		sl_panel.putConstraint(SpringLayout.WEST, panel_2, 300, SpringLayout.WEST, panel);
		sl_panel.putConstraint(SpringLayout.SOUTH, panel_2, 45, SpringLayout.NORTH, panel);
		sl_panel.putConstraint(SpringLayout.EAST, panel_2, 1350, SpringLayout.WEST, panel);
		panel_2.setBackground(new Color(0, 102, 204));
		panel.add(panel_2);
		
		JLabel lblNewLabel_1 = new JLabel("Add Question Bank");
		sl_panel.putConstraint(SpringLayout.WEST, btnAddEam, 22, SpringLayout.WEST, lblNewLabel_1);
		sl_panel.putConstraint(SpringLayout.WEST, lblNewLabel_1, 191, SpringLayout.EAST, panel_1);
		sl_panel.putConstraint(SpringLayout.EAST, lblNewLabel_1, -614, SpringLayout.EAST, panel);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblNewLabel_1);
		
		JLabel lblNewLabel_1_1 = new JLabel("Manage Question Bank");
		sl_panel.putConstraint(SpringLayout.WEST, lblNewLabel_1_1, 924, SpringLayout.WEST, panel);
		sl_panel.putConstraint(SpringLayout.NORTH, lblNewLabel_1, 11, SpringLayout.NORTH, lblNewLabel_1_1);
		sl_panel.putConstraint(SpringLayout.NORTH, lblNewLabel_1_1, 459, SpringLayout.NORTH, panel);
		sl_panel.putConstraint(SpringLayout.SOUTH, lblNewLabel_1_1, -225, SpringLayout.SOUTH, panel);
		sl_panel.putConstraint(SpringLayout.SOUTH, btnManageTest, -13, SpringLayout.NORTH, lblNewLabel_1_1);
		sl_panel.putConstraint(SpringLayout.EAST, lblNewLabel_1_1, 1169, SpringLayout.WEST, panel);
		lblNewLabel_1_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
		lblNewLabel_1_1.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(lblNewLabel_1_1);
		
		/* 
		final JButton btnNewButton_2 = new JButton("Select File For Question");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(e.getSource()== btnNewButton_2)
				{
					JFileChooser fileChosser = new JFileChooser();
					int response=fileChosser.showOpenDialog(null);
					if(response == JFileChooser.APPROVE_OPTION)
					{
						File file=new File(fileChosser.getSelectedFile().getAbsolutePath());
						System.out.println(file);
					}
				}
			}
		});
		sl_panel.putConstraint(SpringLayout.NORTH, btnNewButton_2, -97, SpringLayout.NORTH, btnAddEam);
		sl_panel.putConstraint(SpringLayout.WEST, btnNewButton_2, 263, SpringLayout.EAST, panel_1);
		sl_panel.putConstraint(SpringLayout.SOUTH, btnNewButton_2, -30, SpringLayout.NORTH, btnAddEam);
		sl_panel.putConstraint(SpringLayout.EAST, btnNewButton_2, 396, SpringLayout.EAST, panel_1);
		panel.add(btnNewButton_2);
		*/
		
		ASI.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				StudDis.main(null);
			}
		});
	}
}
