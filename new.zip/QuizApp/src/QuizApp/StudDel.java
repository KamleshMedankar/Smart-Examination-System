package QuizApp;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.Toolkit;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;

import com.mysql.jdbc.PreparedStatement;

import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;
import javax.swing.JTable;
import javax.swing.JScrollPane;

public class StudDel {

	private JFrame frmDeleteStudentData;
	private JTextField RollNo;
	private JTable table;

	void Delete(int RollNo) throws ClassNotFoundException {
		
		 Class.forName("com.mysql.jdbc.Driver");
		 Connection conn = null;
	     Statement stmt = null;
		   try {
			conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/quizapp","root","");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		   
	     try {
			stmt = (Statement) conn.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		 String sql = "DELETE FROM StudInfo WHERE RollNo ="+RollNo;
            

		 try {
			stmt.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}  
		 
		 JOptionPane.showMessageDialog(null,"Data Deleted Successfully");
			StudDel window = new StudDel();
			window.frmDeleteStudentData.setVisible(true);

		
	}
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudDel window = new StudDel();
					window.frmDeleteStudentData.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public StudDel() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {

		frmDeleteStudentData = new JFrame("Edit Student Data");
		frmDeleteStudentData.setTitle("Delete Student Data");
		frmDeleteStudentData.setIconImage(Toolkit.getDefaultToolkit().getImage("O:\\java assignment\\QuizApp\\img\\pngaaa.com-5389762.png"));
		frmDeleteStudentData.setBounds(0, 54, 1350, 675);
		Toolkit kit = Toolkit.getDefaultToolkit();
		Dimension screenSize=kit.getScreenSize();
		int screenWidth = screenSize.width;
		int screenHeight = screenSize.height;

		frmDeleteStudentData.setSize(screenWidth,screenHeight);
		frmDeleteStudentData.setLocationRelativeTo(null);
	
		frmDeleteStudentData.setResizable(false);
		frmDeleteStudentData.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmDeleteStudentData.getContentPane().setLayout(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(153, 0, 0));
		panel.setBounds(0, 0, 1350, 729);
		frmDeleteStudentData.getContentPane().add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Delete Student Data");
		lblNewLabel.setForeground(SystemColor.text);
		lblNewLabel.setFont(new Font("Microsoft YaHei", Font.BOLD, 24));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(0, 76, 1350, 41);
		panel.add(lblNewLabel);
		
		JMenuBar menuBar = new JMenuBar();
		menuBar.setBackground(new Color(255, 153, 51));
		menuBar.setBounds(0, 0, 1523, 52);
		panel.add(menuBar);
		
		JMenu mnNewMenu = new JMenu("Home");
		mnNewMenu.setFont(new Font("Segoe UI", Font.BOLD, 18));
		mnNewMenu.setHorizontalAlignment(SwingConstants.CENTER);
		mnNewMenu.setForeground(new Color(255, 255, 255));
		menuBar.add(mnNewMenu);
		
		
		JMenuItem mntmNewMenuItem3 = new JMenuItem("Add Student Information");
		mntmNewMenuItem3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudUpd.main(null);
			}
		});
		mntmNewMenuItem3.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		mnNewMenu.add(mntmNewMenuItem3);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("Edit Student Information");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudUpd.main(null);
			}
		});
		mntmNewMenuItem.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		mnNewMenu.add(mntmNewMenuItem);
		
		JMenuItem mntmNewMenuItem_1 = new JMenuItem("View Student Information");
		mntmNewMenuItem_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				StudDis.main(null);
			}
		});
		mntmNewMenuItem_1.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		mnNewMenu.add(mntmNewMenuItem_1);
		
	
		
		JMenuItem mntmNewMenuItem_2 = new JMenuItem("Exit");
		mntmNewMenuItem_2.setFont(new Font("Segoe UI", Font.PLAIN, 14));
		mntmNewMenuItem_2.setIcon(new ImageIcon("O:\\java assignment\\QuizApp\\img\\cross.png"));
		mnNewMenu.add(mntmNewMenuItem_2);
		mntmNewMenuItem_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdminPanel.main(null);
			}
		});
		
	
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AdminPanel.main(null);
				frmDeleteStudentData. dispose();
			}
			
		});
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 18));
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.setBackground(new Color(255, 153, 51));
		btnNewButton.setBounds(591, 649, 177, 41);
		panel.add(btnNewButton);
		
		RollNo = new JTextField();
		RollNo.setBounds(551, 140, 409, 41);
		panel.add(RollNo);
		RollNo.setColumns(10);
		
		JButton btnNewButton_1 = new JButton("Delete");
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 14));
		btnNewButton_1.setBackground(new Color(0, 51, 255));
		btnNewButton_1.setForeground(SystemColor.text);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				 String rollno = RollNo.getText();
				
				  StudDel obj = new StudDel();
				    
				  int rollno1 =Integer.parseInt(rollno);
				    try {
						obj.Delete(rollno1);
					} catch (ClassNotFoundException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
			   
				
				
			}
		});
		btnNewButton_1.setBounds(1012, 138, 167, 41);
		panel.add(btnNewButton_1);
		
		JLabel lblNewLabel_1 = new JLabel("Roll Number :");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.BOLD, 20));
		lblNewLabel_1.setForeground(new Color(255, 255, 255));
		lblNewLabel_1.setBounds(360, 142, 167, 28);
		panel.add(lblNewLabel_1);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(88, 214, 1159, 398);
		panel.add(scrollPane);
		
		table = new JTable();
		scrollPane.setViewportView(table);
		
		table.setModel(new DefaultTableModel(
				new Object[][] {
				},
				new String[] {
					"Roll Number", "Name", "Class", "Division", "Student ID", "Password", "Mobile No", "Address"
				}
			));
		

		 try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			 Connection conn = null;
		     Statement st = null;
			   try {
				conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/quizapp","root","");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			   try {
				st = (Statement) conn.createStatement();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			   
			   String sql ="select*from studinfo";
		
				   
				ResultSet rs = null;
				try {
					rs = st.executeQuery(sql);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
		
				
			   try {
				while(rs.next()) {
					String RollNumber=String.valueOf(rs.getInt("RollNo"));
					String Name=rs.getString("Name");
					String Class=rs.getString("Class");
					String Division=rs.getString("Divi");
					String StudentId=rs.getString("StudentId");
					String Password=rs.getString("Pass");
					String MobileNo=rs.getString("MobNo");
					String Address=rs.getString("Address");
					
					String tdData[]= {RollNumber,Name,Class,Division,Password,StudentId,MobileNo,Address};
					
					DefaultTableModel tblModel=(DefaultTableModel)table.getModel();
					tblModel.addRow(tdData);
				   }
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
		
		
		
	}
}
