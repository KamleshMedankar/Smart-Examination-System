package QuizApp;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;

import javax.swing.JLabel;
import java.awt.Color;
import java.awt.event.ActionEvent;
import javax.swing.SwingConstants;
import java.awt.SystemColor;
import java.awt.Panel;
import java.awt.Point;

import javax.swing.ButtonGroup;
import java.awt.event.ActionListener;
import java.awt.Font;

public class ExamTestWindow {

	private JFrame frame;
	private JTextField KeyEventTextField;
    private final ButtonGroup buttonGroup = new ButtonGroup();
    
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ExamTestWindow window = new ExamTestWindow();
					window.frame.setVisible(true);
				
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ExamTestWindow() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 714, 514);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		frame.setCursor(frame.getToolkit().createCustomCursor(new BufferedImage(3, 3, BufferedImage.TYPE_INT_ARGB), new Point(0, 0),"null")); //it is For cursor Off in side frame.
		
		JPanel panel = new JPanel();
		panel.setBackground(SystemColor.text);
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		final JButton b = new JButton("Answer Number  B");
		b.setBackground(Color.WHITE);
		buttonGroup.add(b);
		
		b.setBounds(396, 234, 261, 46);
		panel.add(b);
		
		final JButton d = new JButton("Answer Number  D");
		buttonGroup.add(d);
		d.setBackground(Color.WHITE);
		d.setBounds(396, 309, 261, 46);
		panel.add(d);

		final JButton a = new JButton("Answer Number  A");
		buttonGroup.add(a);
		a.setBackground(Color.WHITE);
		a.setBounds(52, 234, 261, 46);
		panel.add(a);
		
		final JButton c = new JButton("Answer Number  C");
		c.setForeground(Color.BLACK);
		buttonGroup.add(c);
	
		c.setBackground(Color.WHITE);
		c.setBounds(52, 309, 261, 46);
		panel.add(c);
		
		Panel panel_1 = new Panel();
		panel_1.setBackground(Color.GREEN);
		panel_1.setBounds(0, 26, 698, 115);
		panel.add(panel_1);
		panel_1.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Question :");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(66, 52, 90, 14);
		panel_1.add(lblNewLabel);
		
		final JLabel Que = new JLabel("This is a Testing Question Kamlesh Medankar.");
		Que.setFont(new Font("Tahoma", Font.PLAIN, 12));
		Que.setBounds(155, 27, 481, 68);
		panel_1.add(Que);
		Que.setForeground(Color.WHITE);
		Que.setHorizontalAlignment(SwingConstants.LEFT);
        Que.setBackground(Color.WHITE);
		
		
		
		JButton Submit = new JButton("Submit");
		Submit.setBounds(268, 400, 170, 46);
		panel.add(Submit);
		
		//create object of text to speech class
		
		KeyEventTextField = new JTextField(); //This textfield is used for key event
		KeyEventTextField.setEditable(false);
		KeyEventTextField.setBackground(Color.WHITE);
		KeyEventTextField.setHorizontalAlignment(SwingConstants.CENTER);
	
		KeyEventTextField.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				 char key = e.getKeyChar(); 
				 TextToSpeech Ts=new TextToSpeech();
			      if (key == KeyEvent.VK_ENTER) {
			    	   
			    	  Ts.Speack("Submit");
			    	  
			         if(key == KeyEvent.VK_SPACE) {
                   
			    	  Ts.Speack(Que.getText());
			    	  KeyEventTextField.requestFocusInWindow();//set focus in KeyEventTextField.
			      }else if(key == KeyEvent.VK_C) {
                      b.setBackground(Color.WHITE);
                      c.setBackground(Color.WHITE);			    	  
			    	  d.setBackground(Color.WHITE);
			    	  a.setBackground(Color.GREEN);
			    	  Ts.Speack(a.getText());
			    	  KeyEventTextField.requestFocusInWindow();
			      }else if(key == KeyEvent.VK_V) {
			    	  
			    	  a.setBackground(Color.WHITE);
                      c.setBackground(Color.WHITE);			    	  
			    	  d.setBackground(Color.WHITE);
			    	  b.setBackground(Color.GREEN);
			    	  
			    	  Ts.Speack(b.getText());
			    	  KeyEventTextField.requestFocusInWindow();
			      }else if(key == KeyEvent.VK_B) {
			    	  
			    	  a.setBackground(Color.WHITE);
                      b.setBackground(Color.WHITE);			    	  
			    	  c.setBackground(Color.GREEN);
			    	  d.setBackground(Color.WHITE);
			    	  Ts.Speack(c.getText());
			    	  KeyEventTextField.requestFocusInWindow();
			      }else if(key == KeyEvent.VK_N) {
			    	  a.setBackground(Color.WHITE);
                      c.setBackground(Color.WHITE);			    	  
			    	  b.setBackground(Color.WHITE);
			    	  d.setBackground(Color.GREEN);			    	 
			    	  Ts.Speack(d.getText());
			    	  KeyEventTextField.requestFocusInWindow();
			    	  
			      }
			      }
			      
			}
		});
		KeyEventTextField.setBounds(0, 0, 5, 20);
		panel.add(KeyEventTextField);
		KeyEventTextField.setColumns(10);
		
		

		
	}
}
