-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 11, 2022 at 03:42 PM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `quizapp`
--

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

DROP TABLE IF EXISTS `question`;
CREATE TABLE IF NOT EXISTS `question` (
  `QId` int(11) NOT NULL AUTO_INCREMENT,
  `Question` varchar(255) NOT NULL,
  `OpA` varchar(255) NOT NULL,
  `OpB` varchar(255) NOT NULL,
  `OpC` varchar(255) NOT NULL,
  `OpD` varchar(255) NOT NULL,
  `Ans` int(255) DEFAULT NULL,
  PRIMARY KEY (`QId`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`QId`, `Question`, `OpA`, `OpB`, `OpC`, `OpD`, `Ans`) VALUES
(1, 'Number of primitive data types in Java are?\r\n', '6', '7', '8', '9', 3),
(2, 'Which of the following option leads to the portability and security of Java?\r\n\r\n\r\n', 'Bytecode is executed by JVM\r\n', 'The applet makes the Java code secure and portable\r\n', 'Use of exception handling\r\n', 'Dynamic binding between objects', 1),
(3, 'Who invented Java Programming?', 'Guido van Rossum', ' James Gosling', 'Bjarne Stroustrup', ' Dennis Ritchie ', 2),
(4, 'Which statement is true about Java?', 'Java is a sequence-dependent programming language', 'Java is a code dependent programming language', 'Java is a platform-dependent programming language', 'Java is a platform-independent programming language', 4),
(5, 'Which component is used to compile, debug and execute the java programs?', 'JRE\r\n', 'JIT', 'JDK', 'JVM', 3),
(6, 'Which one of the following is not a Java feature?', 'Object-oriented\r\n', 'Use of pointers\r\n', 'Portable', 'Dynamic and Extensible', 2),
(7, 'Which of these cannot be used for a variable name in Java?', 'identifier & keyword\r\n ', 'identifier', 'keyword', 'none of the mentioned', 3),
(8, 'What is the extension of java code files?', '.js\r\n', '.txt', '.class', '.java', 4),
(9, 'Which environment variable is used to set the java path?', 'MAVEN_Path\r\n\r\n', 'JavaPATH', 'JAVA\r\n', 'JAVA_HOME', 4),
(10, 'Which of the following is not an OOPS concept in Java?', 'Polymorphism\r\n', 'Inheritance\r\n', 'Compilation\r\n', 'Encapsulation', 3),
(11, 'Which of the following is a type of polymorphism in Java Programming?', 'Multiple polymorphism\r\n', 'Compile time polymorphism\r\n', 'Multilevel polymorphism\r\n', 'Execution time polymorphism', 2),
(13, 'When an expression consists of int, double, long, float, then the entire expression will get promoted into a data type that is:', 'float\r\n', 'double\r\n\r\n', 'int\r\n', 'long', 2),
(14, 'Which of the following operators can operate on a boolean variable?', '&&', '==', '?:', '+=', 4),
(15, 'What is it called when the child object also gets killed when the parent object is killed in the program?', 'Encapsulation\r \r ', 'b. Association\r ', 'Aggregation\r ', 'Composition', 2);

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

DROP TABLE IF EXISTS `result`;
CREATE TABLE IF NOT EXISTS `result` (
  `ExamID` varchar(255) NOT NULL,
  `Score` int(11) DEFAULT NULL,
  PRIMARY KEY (`ExamID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`ExamID`, `Score`) VALUES
('om123', 1);

-- --------------------------------------------------------

--
-- Table structure for table `studinfo`
--

DROP TABLE IF EXISTS `studinfo`;
CREATE TABLE IF NOT EXISTS `studinfo` (
  `RollNo` int(11) NOT NULL AUTO_INCREMENT,
  `Name` text NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Class` varchar(25) NOT NULL,
  `StudentId` varchar(8) NOT NULL,
  `Pass` varchar(6) NOT NULL,
  `Divi` varchar(10) NOT NULL,
  `MobNo` varchar(10) NOT NULL,
  PRIMARY KEY (`RollNo`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `studinfo`
--

INSERT INTO `studinfo` (`RollNo`, `Name`, `Address`, `Class`, `StudentId`, `Pass`, `Divi`, `MobNo`) VALUES
(8, 'Chaitanya Tawade', 'pimpri', 'te', '1234', '1234', 'b', '1234567890'),
(11, 'tanuja', 'pimpri', 'TE', '44', '1234', 'B', '123422312'),
(12, 'Chaitanay Tawade', 'pune', 'Te', 'ch123', '123', 'B', '1234567890'),
(13, 'om', 'pune', 'te', 'om123', '123', 'b', '1234567833');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
